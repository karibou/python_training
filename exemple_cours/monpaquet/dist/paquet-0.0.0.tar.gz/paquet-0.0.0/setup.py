from distutils.core import setup

setup(name='paquet',)
